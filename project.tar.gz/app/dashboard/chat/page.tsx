'use client';

import { useState, useRef, useEffect } from 'react';
import { 
  Brain, 
  Send, 
  Mic, 
  Paperclip, 
  MoreVertical, 
  User, 
  Bot, 
  Sparkles,
  ChevronLeft,
  ShieldCheck,
  MessageSquare,
  Zap
} from "lucide-react";
import Link from 'next/link';

type Message = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'learning' | 'advocacy' | 'general';
};

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello John! I'm your Cognitive Twin. I've been analyzing your recent learning patterns. Would you like to continue our session on 'Effective Negotiation' or do you need me to advocate for something on your behalf today?",
      timestamp: new Date(),
      type: 'general'
    }
  ]);
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<'learning' | 'advocacy'>('learning');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: mode === 'learning' 
          ? "That's a great point. Based on how you processed the previous concept, let's break this down visually. Imagine the negotiation as a collaborative puzzle rather than a zero-sum game..."
          : "I understand. I'll draft a culturally sensitive and polite request for your fee extension, emphasizing your consistent track record and current situation. Would you like to review the draft first?",
        timestamp: new Date(),
        type: mode
      };
      setMessages(prev => [...prev, aiMessage]);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-screen bg-[#020617] text-slate-200">
      {/* Chat Header */}
      <header className="h-16 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/50 flex items-center justify-between px-6 sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <Link href="/dashboard" className="p-2 hover:bg-slate-900 rounded-full transition-colors">
            <ChevronLeft className="w-5 h-5 text-slate-400" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-700 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Brain className="text-white w-6 h-6" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Neural Twin</h2>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse shadow-lg shadow-cyan-500/50" />
                <span className="text-[10px] font-medium text-slate-500 uppercase tracking-wider">Neural Link Active</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-900/50 p-1 rounded-xl border border-slate-800/50">
          <button 
            onClick={() => setMode('learning')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              mode === 'learning' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Zap className="w-3.5 h-3.5" /> Learning
          </button>
          <button 
            onClick={() => setMode('advocacy')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              mode === 'advocacy' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" /> Advocacy
          </button>
        </div>

        <button className="p-2 text-slate-400 hover:text-slate-600">
          <MoreVertical className="w-5 h-5" />
        </button>
      </header>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 relative">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-500/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-3xl mx-auto space-y-6 relative z-10">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center ${
                  msg.role === 'user' ? 'bg-slate-800' : 'bg-indigo-900/30 border border-indigo-500/20'
                }`}>
                  {msg.role === 'user' ? <User className="w-5 h-5 text-slate-400" /> : <Bot className="w-5 h-5 text-indigo-400" />}
                </div>
                <div className={`space-y-1 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                  <div className={`p-4 rounded-2xl text-sm leading-relaxed shadow-xl backdrop-blur-md ${
                    msg.role === 'user' 
                      ? 'bg-indigo-600 text-white rounded-tr-none' 
                      : 'bg-slate-900/80 text-slate-200 border border-slate-800/50 rounded-tl-none'
                  }`}>
                    {msg.content}
                  </div>
                  <span className="text-[10px] text-slate-400 px-1">
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    {msg.type && msg.type !== 'general' && (
                      <span className="ml-2 font-bold uppercase text-indigo-400">· {msg.type}</span>
                    )}
                  </span>
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="p-6 bg-slate-950/80 backdrop-blur-xl border-t border-slate-800/50">
        <div className="max-w-3xl mx-auto">
          <div className="relative flex items-end gap-2 bg-slate-900/50 border border-slate-800/50 rounded-2xl p-2 focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 transition-all">
            <button className="p-2 text-slate-400 hover:text-indigo-600 transition-colors">
              <Paperclip className="w-5 h-5" />
            </button>
            <textarea 
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={mode === 'learning' ? "Ask me to explain something..." : "What should I advocate for?"}
              className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-2 resize-none max-h-32 text-slate-200 placeholder:text-slate-500"
            />
            <button className="p-2 text-slate-400 hover:text-indigo-600 transition-colors">
              <Mic className="w-5 h-5" />
            </button>
            <button 
              onClick={handleSend}
              disabled={!input.trim()}
              className="p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-all shadow-lg shadow-indigo-500/20"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <div className="mt-3 flex items-center justify-center gap-4">
            <p className="text-[10px] text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Powered by Azure AI Reasoning
            </p>
            <p className="text-[10px] text-slate-400 flex items-center gap-1">
              <MessageSquare className="w-3 h-3" /> Multilingual Support Active
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
